import csv
import os
import time
import struct
import json
import subprocess
import psutil
import numpy as np
from dask.distributed import Client


#cluster coordinates
#this script mast be launched on the scheduler VM
SCHEDULER_IP   = "10.67.22.68"
ALL_WORKERS    = ["10.67.22.154", "10.67.22.91", "10.67.22.15", "10.67.22.43"]
DASK_BIN       = "/home/cluster/pyvenv/bin/dask"
SSH_USER       = "ubuntu"
SSH_KEY        = "~/.ssh/dask_cluster_key"
SCHEDULER_PORT = 8786
DASHBOARD_PORT = 8797

# same dimensions as the old bm to generate the fake dataset, then split into slices
rows = 8192
cols = 1024
FFT_SIZE = 2048  # must match FFT_SIZE in the online pipeline

# param
workers_list = [1, 2, 3, 4]  # one vCPU per worker VM, so four workers is the ceiling
slices_list  = [1, 2, 4, 8, 16, 32]
repetitions  = 10
#to compute a sort of 'throughput'
data_size_MB = (rows * cols * 4 * 2) / (1024**2)  # header overhead excluded

output_csv = "benchmark_cluster_dask.csv"

#same f. as online
def compute_fft_chunk(raw, header_len, n_bytes_i, n_bytes_q):
    payload = memoryview(raw)[4 + header_len:]
    chunk_i = np.frombuffer(payload[:n_bytes_i], dtype="<f4")
    chunk_q = np.frombuffer(payload[n_bytes_i:n_bytes_i + n_bytes_q], dtype="<f4")

    signal = chunk_i + 1j * chunk_q
    matrix = signal.reshape(-1, FFT_SIZE)
    n_scans = len(matrix)
    ps = np.abs(np.fft.fft(matrix, axis=1)) ** 2
    return ps.mean(axis=0), ps.std(axis=0), n_scans


def combine_chunks(batch_id, timestamp, results):
    total_scans = 0
    for r in results:
        total_scans += r[2]
    #mean
    weighted_mean_sum = 0
    for r in results:
        weighted_mean_sum += r[2] * r[0]
    combined_mean = weighted_mean_sum / total_scans
    #comb var
    weighted_var_sum = 0
    for r in results:
        weighted_var_sum += r[2] * (r[1] ** 2 + (r[0] - combined_mean) ** 2)
    combined_std = np.sqrt(weighted_var_sum / total_scans)

    return batch_id, timestamp, combined_mean, combined_std


# build a fake  message for one slice 
def build_slice_raw(batch_id, slice_idx, n_slices, timestamp, i_slice, q_slice):
    i_bytes = i_slice.astype("<f4").tobytes()
    q_bytes = q_slice.astype("<f4").tobytes()

    header = {
        "batch_id": batch_id,
        "slice_idx": slice_idx,
        "n_slices": n_slices,
        "timestamp": timestamp,
        "n_bytes_i": len(i_bytes),
        "n_bytes_q": len(q_bytes),
    }
    header_bytes = json.dumps(header).encode("utf-8")
    header_len = len(header_bytes)
    raw = struct.pack(">I", header_len) + header_bytes + i_bytes + q_bytes

    return raw, header_len, len(i_bytes), len(q_bytes)



def ssh(host, command):
    return subprocess.run(
        ["ssh", "-n", "-i", os.path.expanduser(SSH_KEY),
         "-o", "StrictHostKeyChecking=no",
         f"{SSH_USER}@{host}", command],
        check=False, capture_output=True, text=True,
    )


def start_scheduler():
    return subprocess.Popen(
        [DASK_BIN, "scheduler",
         "--port", str(SCHEDULER_PORT),
         "--dashboard-address", f":{DASHBOARD_PORT}"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def start_workers(hosts):
    for host in hosts:
        #-n so ssh does not read local stdin, so the loop moves on to the next VM
        ssh(host,
            f"nohup {DASK_BIN} worker tcp://{SCHEDULER_IP}:{SCHEDULER_PORT} "
            f"--nworkers 1 --nthreads 1 > /dev/null 2>&1 < /dev/null &")


def stop_workers(hosts):
    for host in hosts:
        ssh(host, "pkill -f '[d]ask worker'")


def wait_for_no_workers(client, timeout=120):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if len(client.scheduler_info()["workers"]) == 0:
            return
        time.sleep(1)
    raise RuntimeError("some workers are still registered on the scheduler")



def workers_cpu_reset(client):
    client.run(psutil.cpu_percent)


def workers_cpu_mean(client):
    values = client.run(psutil.cpu_percent)
    return sum(values.values()) / len(values)


def workers_mem_mean(client):
    values = client.run(lambda: psutil.virtual_memory().percent)
    return sum(values.values()) / len(values)


#t_scatter + t_submit ~= sum of "dask_submit" online (scatter+submit per single slice)
#t_submit_gather + t_gather ~= "dask_compute" online

def init_csv(path):
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "n_workers", "n_slices", "repetition",
            "t_scatter", "t_submit", "t_submit_gather", "t_gather", "t_total", "throughput_MB_s",
            "cpu_during_client", "cpu_during_workers", "mem_before_workers", "mem_after_workers"
        ])


def append_row(path, n_workers, n_slices, rep,
               t_scatter, t_submit, t_submit_gather, t_gather, t_total, throughput,
               cpu_during_client, cpu_during_workers, mem_before_workers, mem_after_workers):

    with open(path, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            n_workers, n_slices, rep, t_scatter, t_submit, t_submit_gather, t_gather, t_total,
            throughput, cpu_during_client, cpu_during_workers, mem_before_workers, mem_after_workers
        ])



def run_single(client, n_workers, n_slices, rep):
    # generate a fake batch
    data_i = np.random.uniform(-1, 1, (rows, cols)).astype("float32")
    data_q = np.random.uniform(-1, 1, (rows, cols)).astype("float32")

    # split into slices along row axis
    slices_i = np.array_split(data_i, n_slices, axis=0)
    slices_q = np.array_split(data_q, n_slices, axis=0)

    batch_id = f"bench_{n_workers}w_{n_slices}s_{rep}"
    timestamp = time.time()

    messages = [
        build_slice_raw(batch_id, idx, n_slices, timestamp, i_s, q_s)
        for idx, (i_s, q_s) in enumerate(zip(slices_i, slices_q))
    ]

    # reset the cpu reference on the workers and on this machine, then read both back
    # after t_total to get the mean load over exactly the measured window
    workers_cpu_reset(client)
    psutil.cpu_percent(interval=None)
    mem_before_workers = workers_mem_mean(client)

    t_total_start = time.perf_counter()

    t_scatter = 0.0
    t_submit = 0.0
    chunk_futures = []
    for raw, header_len, n_bytes_i, n_bytes_q in messages:
        t_scatter_start = time.perf_counter()
        raw_future = client.scatter(raw)
        t_scatter += time.perf_counter() - t_scatter_start

        t_submit_start = time.perf_counter()
        chunk_future = client.submit(compute_fft_chunk, raw_future, header_len, n_bytes_i, n_bytes_q)
        t_submit += time.perf_counter() - t_submit_start

        chunk_futures.append(chunk_future)

    t_submit_gather_start = time.perf_counter()
    combine_future = client.submit(combine_chunks, batch_id, timestamp, chunk_futures)
    t_submit_gather = time.perf_counter() - t_submit_gather_start

    t_gather_start = time.perf_counter()
    _, _, combined_mean, combined_std = client.gather(combine_future)
    t_gather = time.perf_counter() - t_gather_start

    t_total = time.perf_counter() - t_total_start

    cpu_during_client = psutil.cpu_percent(interval=None)
    cpu_during_workers = workers_cpu_mean(client)
    mem_after_workers = workers_mem_mean(client)

    return (t_scatter, t_submit, t_submit_gather, t_gather, t_total,
            cpu_during_client, cpu_during_workers, mem_before_workers, mem_after_workers)


def main():
    psutil.cpu_percent()
    init_csv(output_csv)

    #leftovers from a previous run would be counted as workers of this one
    stop_workers(ALL_WORKERS)

    scheduler = start_scheduler()
    time.sleep(5)
    print(f"dashboard: http://{SCHEDULER_IP}:{DASHBOARD_PORT}/status")

    try:
        client = Client(f"tcp://{SCHEDULER_IP}:{SCHEDULER_PORT}", timeout="60s")

        for n_workers in workers_list:
            start_workers(ALL_WORKERS[:n_workers])
            client.wait_for_workers(n_workers, timeout="120s")
            print(f"{n_workers} worker(s) up: {sorted(client.scheduler_info()['workers'])}")

            for n_slices in slices_list:
                for rep in range(1, repetitions + 1):
                    (t_scatter, t_submit, t_submit_gather, t_gather, t_total,
                     cpu_during_client, cpu_during_workers,
                     mem_before_workers, mem_after_workers) = run_single(client, n_workers, n_slices, rep)

                    throughput = data_size_MB / t_total

                    append_row(output_csv, n_workers, n_slices, rep,
                               t_scatter, t_submit, t_submit_gather, t_gather, t_total,
                               throughput,
                               cpu_during_client, cpu_during_workers,
                               mem_before_workers, mem_after_workers)

                    print(f"workers={n_workers} slices={n_slices} rep={rep} "
                          f"scatter={t_scatter:.3f}s submit={t_submit:.3f}s "
                          f"submit_combine={t_submit_gather:.3f}s gather={t_gather:.3f}s total={t_total:.3f}s")

            stop_workers(ALL_WORKERS[:n_workers])
            wait_for_no_workers(client)

        client.close()
    finally:
        stop_workers(ALL_WORKERS)
        scheduler.terminate()
        scheduler.wait()


if __name__ == "__main__":
    main()
