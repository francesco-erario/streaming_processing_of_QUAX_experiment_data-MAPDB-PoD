import csv
import time
import struct
import json
import psutil
import numpy as np
from dask.distributed import Client, LocalCluster

rows = 8192
cols = 1024
FFT_SIZE = 2048  # must match FFT_SIZE in the online pipeline

# param
workers_list = [1, 2, 4, 8]
slices_list  = [1, 2, 4, 8, 16, 32]
repetitions  = 10
#to compute a sort of 'troughput'
data_size_MB = (rows * cols * 4 * 2) / (1024**2)  # header overhead excluded

output_csv = "benchmark_offline_dask.csv"

#same f. as online
def compute_fft_chunk(raw, header_len, n_bytes_i, n_bytes_q):
    payload = memoryview(raw)[4 + header_len:]
    chunk_i = np.frombuffer(payload[:n_bytes_i], dtype="<f4")
    chunk_q = np.frombuffer(payload[n_bytes_i:n_bytes_i + n_bytes_q], dtype="<f4")

    signal = chunk_i + 1j * chunk_q
    matrix = signal.reshape(-1, FFT_SIZE)
    n_scans = len(matrix)
    ps = np.abs(np.fft.fft(matrix, axis=1)) ** 2
    return ps.mean(axis=0), ps.std(axis=0), n_scans


def combine_chunks(batch_id, timestamp, results):
    total_scans = 0
    for r in results:
        total_scans += r[2]
    #mean
    weighted_mean_sum = 0
    for r in results:
        weighted_mean_sum += r[2] * r[0]
    combined_mean = weighted_mean_sum / total_scans
    #comb var
    weighted_var_sum = 0
    for r in results:
        weighted_var_sum += r[2] * (r[1] ** 2 + (r[0] - combined_mean) ** 2)
    combined_std = np.sqrt(weighted_var_sum / total_scans)

    return batch_id, timestamp, combined_mean, combined_std


# build a fake "raw" message for one slice 
def build_slice_raw(batch_id, slice_idx, n_slices, timestamp, i_slice, q_slice):
    i_bytes = i_slice.astype("<f4").tobytes()
    q_bytes = q_slice.astype("<f4").tobytes()

    header = {
        "batch_id": batch_id,
        "slice_idx": slice_idx,
        "n_slices": n_slices,
        "timestamp": timestamp,
        "n_bytes_i": len(i_bytes),
        "n_bytes_q": len(q_bytes),
    }
    header_bytes = json.dumps(header).encode("utf-8")
    header_len = len(header_bytes)
    raw = struct.pack(">I", header_len) + header_bytes + i_bytes + q_bytes

    return raw, header_len, len(i_bytes), len(q_bytes)


#t_scatter + t_submit ~= sum of "dask_submit" online (scatter+submit per single slice)
#t_submit_gather + t_gather ~= "dask_compute" online

def init_csv(path):
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "n_workers", "n_slices", "repetition",
            "t_scatter", "t_submit", "t_submit_gather", "t_gather", "t_total", "throughput_MB_s",
            "cpu_during", "mem_before", "mem_after"
        ])


def append_row(path, n_workers, n_slices, rep,
               t_scatter, t_submit, t_submit_gather, t_gather, t_total, throughput,
               cpu_during, mem_before, mem_after):

    with open(path, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            n_workers, n_slices, rep, t_scatter, t_submit, t_submit_gather, t_gather, t_total,
            throughput, cpu_during, mem_before, mem_after
        ])



def run_single(client, n_workers, n_slices, rep):
    # generate a fake batch
    data_i = np.random.uniform(-1, 1, (rows, cols)).astype("float32")
    data_q = np.random.uniform(-1, 1, (rows, cols)).astype("float32")

    # split into slices along row axis
    slices_i = np.array_split(data_i, n_slices, axis=0)
    slices_q = np.array_split(data_q, n_slices, axis=0)

    batch_id = f"bench_{n_workers}w_{n_slices}s_{rep}"
    timestamp = time.time()

    messages = [
        build_slice_raw(batch_id, idx, n_slices, timestamp, i_s, q_s)
        for idx, (i_s, q_s) in enumerate(zip(slices_i, slices_q))
    ]

    # for cpu: interval=None should ret. the avg since the previous interval=None call, so calling it
    # here resets the ref. and the call after t_total gives the mean cpu load over
        psutil.cpu_percent(interval=None)
    mem_before = psutil.virtual_memory().percent

    t_total_start = time.perf_counter()

    # scatter+submit interleaved slice by slice like the online pipeline
    t_scatter = 0.0
    t_submit = 0.0
    chunk_futures = []
    for raw, header_len, n_bytes_i, n_bytes_q in messages:
        t_scatter_start = time.perf_counter()
        raw_future = client.scatter(raw)
        t_scatter += time.perf_counter() - t_scatter_start

        t_submit_start = time.perf_counter()
        chunk_future = client.submit(compute_fft_chunk, raw_future, header_len, n_bytes_i, n_bytes_q)
        t_submit += time.perf_counter() - t_submit_start

        chunk_futures.append(chunk_future)

    t_submit_gather_start = time.perf_counter()
    combine_future = client.submit(combine_chunks, batch_id, timestamp, chunk_futures)
    t_submit_gather = time.perf_counter() - t_submit_gather_start

    t_gather_start = time.perf_counter()
    _, _, combined_mean, combined_std = client.gather(combine_future)
    t_gather = time.perf_counter() - t_gather_start

    t_total = time.perf_counter() - t_total_start

    cpu_during = psutil.cpu_percent(interval=None)
    mem_after = psutil.virtual_memory().percent

    return t_scatter, t_submit, t_submit_gather, t_gather, t_total, cpu_during, mem_before, mem_after


def main():
    psutil.cpu_percent()
    init_csv(output_csv)

    for n_workers in workers_list:
        cluster = LocalCluster(n_workers=n_workers, threads_per_worker=1)
        client = Client(cluster)
        print(f"dashboard: {cluster.dashboard_link}")

        for n_slices in slices_list:
            for rep in range(1, repetitions + 1):
                (t_scatter, t_submit, t_submit_gather, t_gather, t_total,
                 cpu_during, mem_before, mem_after) = run_single(client, n_workers, n_slices, rep)

                throughput = data_size_MB / t_total

                append_row(output_csv, n_workers, n_slices, rep,
                           t_scatter, t_submit, t_submit_gather, t_gather, t_total,
                           throughput,
                           cpu_during, mem_before, mem_after)

                print(f"workers={n_workers} slices={n_slices} rep={rep} "
                      f"scatter={t_scatter:.3f}s submit={t_submit:.3f}s "
                      f"submit_combine={t_submit_gather:.3f}s gather={t_gather:.3f}s total={t_total:.3f}s")

        client.close()
        cluster.close()


if __name__ == "__main__":
    main()
