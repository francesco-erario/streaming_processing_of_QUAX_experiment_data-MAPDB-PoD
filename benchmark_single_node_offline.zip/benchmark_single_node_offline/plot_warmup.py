import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from cycler import cycler
import matplotlib.cm as cm

csv_path = 'benchmark_offline_dask.csv'
out_dir  = 'plots_warmup'

cmap = cm.get_cmap('plasma')
plt.rcParams['axes.prop_cycle'] = cycler(color=[cmap(0.2), cmap(0.5), cmap(0.8)])
plt.rcParams.update({'font.size': 13, 'axes.titlesize': 14, 'axes.labelsize': 13, 'xtick.labelsize': 11, 'ytick.labelsize': 11, 'legend.fontsize': 11})

df = pd.read_csv(csv_path)

slices_list  = sorted(df['n_slices'].unique())
workers_list = sorted(df['n_workers'].unique())

metrics = ['t_total', 't_scatter', 't_gather']

for n_slices in slices_list:

    fig, axes = plt.subplots(2, 2, figsize=(10, 7))
    fig.suptitle(f'Warmup analysis  n_slices = {n_slices}', fontsize=14)
    axes_flat = axes.flatten()

    for idx, n_workers in enumerate(workers_list):
        ax = axes_flat[idx]
        sub = df[(df['n_slices'] == n_slices) & (df['n_workers'] == n_workers)].sort_values('repetition')

        reps = sub['repetition'].values

        for col in metrics:
            ax.plot(reps, sub[col].values, marker='o', linewidth=1.2, markersize=4, label=col)

        ax.set_title(f'n_workers = {n_workers}')
        ax.set_xlabel('repetition')
        ax.set_ylabel('time (s)')
        ax.set_xticks(reps)
        ax.grid(True, linestyle='--', alpha=0.4)

    handles, labels = axes_flat[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', ncol=3, bbox_to_anchor=(0.5, 0.01))

    fig.tight_layout(rect=[0, 0.06, 1, 0.96])
    out_path = out_dir + '/warmup_slices' + str(n_slices) + '.png'
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    print('saved ' + out_path)