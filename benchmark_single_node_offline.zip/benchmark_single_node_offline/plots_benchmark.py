import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from cycler import cycler
import matplotlib.cm as cm

csv_path = 'benchmark_offline_dask.csv'
out_dir  = 'plots_benchmark'

cmap = cm.get_cmap('plasma')
plt.rcParams.update({'font.size': 13, 'axes.titlesize': 14, 'axes.labelsize': 13, 'xtick.labelsize': 11, 'ytick.labelsize': 11, 'legend.fontsize': 11})

df = pd.read_csv(csv_path)

slices_list  = sorted(df['n_slices'].unique())
workers_list = sorted(df['n_workers'].unique())

agg = df.groupby(['n_workers', 'n_slices']).agg(
    t_total_med        = ('t_total','median'),
    t_total_min        = ('t_total','min'),
    t_total_max        = ('t_total', 'max'),
    throughput_med     = ('throughput_MB_s','median'),
    throughput_min     = ('throughput_MB_s','min'),
    throughput_max     = ('throughput_MB_s','max'),
    t_scatter_med      = ('t_scatter','median'),
    t_submit_med       = ('t_submit','median'),
    t_submit_gather_med= ('t_submit_gather','median'),
    t_gather_med       = ('t_gather','median'),
).reset_index()

n_slices_colors  = {s: cmap(i / (len(slices_list)  - 1) * 0.85) for i, s in enumerate(slices_list)}
n_workers_colors = {w: cmap(i / (len(workers_list) - 1) * 0.85) for i, w in enumerate(workers_list)}


# first plot
fig, ax = plt.subplots(figsize=(8, 5))
for n_slices in slices_list:
    sub = agg[agg['n_slices'] == n_slices].sort_values('n_workers')
    yerr_lo = sub['t_total_med'] - sub['t_total_min']
    yerr_hi = sub['t_total_max'] - sub['t_total_med']
    ax.errorbar(sub['n_workers'], sub['t_total_med'],
                yerr=[yerr_lo, yerr_hi], marker='o', linewidth=1.5,
                markersize=5, capsize=4, label=f'n_slices={n_slices}',
                color=n_slices_colors[n_slices])
ax.set_xlabel('n_workers')
ax.set_ylabel('t_total (s)')
ax.set_title('Total time vs number of workers')
ax.set_xticks(workers_list)
ax.legend()
fig.tight_layout()
fig.savefig(out_dir + '/t_total_vs_workers.png', dpi=150)
plt.close(fig)
print('saved t_total_vs_workers.png')


#second plot
fig, ax = plt.subplots(figsize=(8, 5))
for n_slices in slices_list:
    sub = agg[agg['n_slices'] == n_slices].sort_values('n_workers')
    yerr_lo = sub['throughput_med'] - sub['throughput_min']
    yerr_hi = sub['throughput_max'] - sub['throughput_med']
    ax.errorbar(sub['n_workers'], sub['throughput_med'],
                yerr=[yerr_lo, yerr_hi], marker='o', linewidth=1.5,
                markersize=5, capsize=4, label=f'n_slices={n_slices}',
                color=n_slices_colors[n_slices])
ax.set_xlabel('n_workers')
ax.set_ylabel('throughput (MB/s)')
ax.set_title('Throughput vs number of workers')
ax.set_xticks(workers_list)
ax.legend()
fig.tight_layout()
fig.savefig(out_dir + '/throughput_vs_workers.png', dpi=150)
plt.close(fig)
print('saved throughput_vs_workers.png')


#3 plot
fig, ax = plt.subplots(figsize=(8, 5))
for n_workers in workers_list:
    sub = agg[agg['n_workers'] == n_workers].sort_values('n_slices')
    yerr_lo = sub['t_total_med'] - sub['t_total_min']
    yerr_hi = sub['t_total_max'] - sub['t_total_med']
    ax.errorbar(sub['n_slices'], sub['t_total_med'],
                yerr=[yerr_lo, yerr_hi], marker='o', linewidth=1.5, markersize=5, capsize=4, label=f'n_workers={n_workers}',
                color=n_workers_colors[n_workers])
ax.set_xlabel('n_slices')
ax.set_ylabel('t_total (s)')
ax.set_title('Total time vs number of slices')
ax.set_xticks(slices_list)
ax.legend()
fig.tight_layout()
fig.savefig(out_dir + '/t_total_vs_slices.png', dpi=150)
plt.close(fig)
print('saved t_total_vs_slices.png')


# 4 plot
fig, ax = plt.subplots(figsize=(8, 5))
for n_workers in workers_list:
    sub = agg[agg['n_workers'] == n_workers].sort_values('n_slices')
    yerr_lo = sub['throughput_med'] - sub['throughput_min']
    yerr_hi = sub['throughput_max'] - sub['throughput_med']
    ax.errorbar(sub['n_slices'], sub['throughput_med'], yerr=[yerr_lo, yerr_hi], marker='o', linewidth=1.5,
                markersize=5, capsize=4, label=f'n_workers={n_workers}',
                color=n_workers_colors[n_workers])
ax.set_xlabel('n_slices')
ax.set_ylabel('throughput (MB/s)')
ax.set_title('Throughput vs number of slices')
ax.set_xticks(slices_list)
ax.legend()
fig.tight_layout()
fig.savefig(out_dir + '/throughput_vs_slices.png', dpi=150)
plt.close(fig)
print('saved throughput_vs_slices.png')


# 5 plot
stages = ['t_scatter', 't_submit', 't_submit_gather', 't_gather']
stage_colors = [cmap(0.2), cmap(0.4), cmap(0.6), cmap(0.8)]

for n_slices in slices_list:
    sub = agg[agg['n_slices'] == n_slices].sort_values('n_workers')
    x = range(len(workers_list))
    fig, ax = plt.subplots(figsize=(7, 5))
    bottom = [0] * len(workers_list)
    for stage, color in zip(stages, stage_colors):
        vals = sub[stage + '_med'].values
        ax.bar(x, vals, label=stage, color=color, bottom=bottom)
        bottom = [b + v for b, v in zip(bottom, vals)]
    ax.set_xticks(list(x))
    ax.set_xticklabels([f'n_workers={w}' for w in workers_list])
    ax.set_ylabel('time (s)')
    ax.set_title(f'Time decomposition  n_slices={n_slices}')
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir + '/decomposition_slices' + str(n_slices) + '.png', dpi=150)
    plt.close(fig)
    print('saved decomposition_slices' + str(n_slices) + '.png')